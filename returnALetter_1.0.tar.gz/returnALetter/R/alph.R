alph <-
function(x){
  sample(letters,1)
}
